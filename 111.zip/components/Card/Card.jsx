import React from "react";
import "./Card.css";

export default function Card({ photo, title, description }) {
  return (
    <div className="card">
      <div>
        <img src={photo} alt="" />
      </div>
      <div>
        <h2>{title}</h2>
      </div>
      <div>
        <p>{description}</p>
      </div>
    </div>
  );
}
