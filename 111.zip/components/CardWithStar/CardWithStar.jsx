import React from "react";
import "./CardWithStar.css";
import Rating from "@mui/material/Rating";

export default function CardWithStar({ image, p1, p2, p3, rate, name }) {
  return (
    <div className="card-stars">
      <img src={image} alt="" />
      <p>
        {p1} <br />
        {p2} <br />
        {p3}
      </p>
      <div>
        <Rating name="read-only" value={5} readOnly />
      </div>
      <h3>{name}</h3>
    </div>
  );
}
