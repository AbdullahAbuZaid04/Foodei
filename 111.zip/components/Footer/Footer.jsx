import React from "react";
import "./Footer.css";

export default function Footer() {
  return (
    <div className="footer">
      <div className="col1">
        <h1>FOODIE</h1>
        <ul>
          <li>
            <i>Twiter</i>
            <i>LinkedIn</i>
            <i>Youtube</i>
            <i>FaceBook</i>
          </li>
        </ul>
      </div>
      <div className="col2">
        <ul>
          <li>Quality</li>
          <li>Quality</li>
          <li>Quality</li>
          <li>Quality</li>
          <li>Quality</li>
          <li>Quality</li>
        </ul>
      </div>
      <div className="col3">
        <ul>
          <li>244-5333-7783</li>
          <li>hello@food.com</li>
          <li>press@food.com</li>
          <li>contact@food.com</li>
        </ul>
      </div>
      <div className="col4">
        <ul>
          <li>Terms & Conditions</li>
          <li>Privacy Policy</li>
        </ul>
      </div>
    </div>
  );
}
