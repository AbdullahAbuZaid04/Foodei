import React from "react";
import Button from "../Button/Button";
import "./Hero1.css";
import background from "../../assets/home-banner-background.png";
import image from "../../assets/home-banner-image.png";

export default function Hero1({ text, icon }) {
  return (
    <div className="container-content">
      <div className="container-texts">
        <h1 className="title">Your Favourite Food Delivered Hot & Fresh</h1>
        <p className="des">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Exercitationem reiciendis officia nulla ipsam consequuntur laudantium
          laborum iusto cupiditate, aperiam incidunt.
        </p>
        <Button text={text} />
        <div className="container-image">
          <img src={background} alt="" className="img1" />
          <img src={image} alt="" className="img2" />
        </div>
      </div>
    </div>
  );
}
