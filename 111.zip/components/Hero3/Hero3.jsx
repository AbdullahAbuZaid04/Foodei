import React from "react";
import "./Hero3.css";
import TitleText from "../TitleText/TitleText";
import Card from "../Card/Card";
import photo1 from "../../assets/pick-meals-image.png";
import photo2 from "../../assets/choose-image.png";
import photo3 from "../../assets/delivery-image.png";

export default function Hero3() {
  return (
    <div className="hero3">
      <TitleText
        type={"work"}
        title={"How It Works"}
        p1={"Lorem ipsum dolor sit amet consectetur. Non tincidunt"}
        p2={"magna non et elit. Dolor turpis molestie dui"}
        p3={"magnis facilisis at fringilla quam."}
      />

      <div className="cards">
        <Card
          photo={photo1}
          title={"Pick Meals"}
          description={
            "Lorem ipsum dolor sit amet consectetur. More orci and sagittis duis elementum interdum facilisi bibendum."
          }
        />

        <Card
          photo={photo2}
          title={"Choose How Often"}
          description={
            "Lorem ipsum dolor sit amet consectetur. More orci and sagittis duis elementum interdum facilisi bibendum."
          }
        />

        <Card
          photo={photo3}
          title={"Fast Deliveries"}
          description={
            "Lorem ipsum dolor sit amet consectetur. More orci and sagittis duis elementum interdum facilisi bibendum."
          }
        />
      </div>
    </div>
  );
}
