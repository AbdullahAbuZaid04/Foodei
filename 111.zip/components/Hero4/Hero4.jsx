import React from "react";
import TitleText from "../TitleText/TitleText";
import CardWithStar from "../CardWithStar/CardWithStar";
import photo from "../../assets/john-doe-image.png";
import "./Hero4.css";

export default function Hero4() {
  return (
    <div className="hero4">
      <TitleText
        type={"Testimonial"}
        title={"What They Are Saying"}
        p1={"Lorem ipsum dolor sit amet consectetur. Non tincidunt"}
        p2={"magna non et elit. Dolor turpis molestie dui"}
        p3={"magnis facilisis at fringilla quam."}
      />

      <CardWithStar
        image={photo}
        p1={"Lorem ipsum dolor sit amet consectetur. Non tincidunt"}
        p2={"magna non et elit. Dolor turpis molestie dui"}
        p3={"magnis facilisis at fringilla quam."}
        rate={5}
        name={"John Doe"}
      />
    </div>
  );
}
