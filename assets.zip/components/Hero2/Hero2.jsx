import React from "react";
import background from "../../assets/about-background.png";
import image from "../../assets/about-background-image.png";
import Button from "../Button/Button";
import "./Hero2.css";

// export default function Hero2({ text }) {
//   return (
//     <div>
//       <div className="container-content2">
//         <div className="container-image2">
//           <img src={background} alt="" className="img1" />
//           <img src={image} alt="" className="img2" />
//         </div>
//         <div className="container-texts2">
//           <h1 className="title2">Your Favourite Food Delivered Hot & Fresh</h1>
//           <p className="des2">
//             Lorem ipsum dolor sit amet consectetur adipisicing elit.
//             Exercitationem reiciendis officia nulla ipsam consequuntur
//             laudantium laborum iusto cupiditate, aperiam incidunt.
//           </p>
//           <Button text={text} />
//         </div>
//       </div>
//     </div>
//   );
// }

export default function Hero2({ text }) {
  return (
    <div className="container-content2">
      {/* حاوية الصور - ستكون على اليسار */}
      <div className="container-image2">
        <img src={background} alt="" className="about-bg" />
        <img src={image} alt="" className="about-img" />
      </div>

      {/* حاوية النصوص - ستكون على اليمين */}
      <div className="container-texts2">
        <h1 className="title2">Your Favourite Food Delivered Hot & Fresh</h1>
        <p className="des2">
          Lorem ipsum dolor sit amet consectetur adipisicing elit.
          Exercitationem reiciendis officia nulla ipsam...
        </p>
        <Button text={text} />
      </div>
    </div>
  );
}
