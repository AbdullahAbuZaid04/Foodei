import React from "react";
import "./Hero5.css";

export default function Hero5() {
  return (
    <div className="hero5">
      <h1>Have Question In Mind? Let Us Help You</h1>
      <div className="hero5-btn">
        <input type="email" placeholder="yourmail@gmail.com" />
        <button>Submit</button>
      </div>
    </div>
  );
}
