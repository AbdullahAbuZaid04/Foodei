import React from "react";
import "./Navbar.css";

export default function Navbar() {
  const links = [
    "Home",
    "About",
    "Testimonials",
    "Contact",
    "cart",
    "Booking Now",
  ];
  return (
    <div className="container">
      <header>
        <h1 className="logo">FOODIE</h1>
        <nav>
          <ul>
            {links.map((l, index) => (
              <li key={index}>{l}</li>
            ))}
          </ul>
        </nav>
      </header>
    </div>
  );
}
