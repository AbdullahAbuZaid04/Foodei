import "./TitleText.css";

export default function TitleText({ type, title, p1, p2, p3 }) {
  return (
    <div className="content">
      <span>{type}</span>
      <h2>{title}</h2>
      <p>
        {p1} <br />
        {p2} <br />
        {p3}
      </p>
    </div>
  );
}
